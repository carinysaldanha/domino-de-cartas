from codigo_fonte.main import menu

if __name__ == "__main__":
    menu()
